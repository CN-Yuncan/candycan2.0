import './index.css'

export { default as Rain } from '@/assets/svg/rain.svg'
export { default as Snow } from '@/assets/svg/snow.svg'
export { default as Sun } from '@/assets/svg/sun.svg'
export { default as Sunshine } from '@/assets/svg/sunshine.svg'
export { default as Thunder } from '@/assets/svg/thunder.svg'
export { default as Windy } from '@/assets/svg/windy.svg'
