'use client'

import 'react-photo-view/dist/react-photo-view.css'

export { PhotoProvider, PhotoView } from 'react-photo-view'
