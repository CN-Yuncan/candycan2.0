const config = {
  contact: {
    github: 'https://github.com/chanshiyucx',
    twitter: 'https://twitter.com/chanshiyucx',
    telegram: 'https://t.me/chanshiyucx',
    email: 'mailto://me@chanshiyu.com',
    music: 'https://music.163.com/#/user/home?id=103060582',
    blog: 'https://chanshiyu.gitbook.io/blog',
  },
}

export default config
